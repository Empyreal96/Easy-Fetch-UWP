﻿using System;

namespace SharpCompress.Common
{
    public interface IVolume : IDisposable
    {
    }
}