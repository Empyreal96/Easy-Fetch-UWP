﻿namespace SharpCompress.Common.SevenZip
{
    internal class CBindPair
    {
        internal int _inIndex;
        internal int _outIndex;
    }
}