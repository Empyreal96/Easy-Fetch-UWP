﻿namespace SharpCompress.Common.Rar.Headers
{
    internal interface IRarHeader
    {
        HeaderType HeaderType { get; }
    }
}