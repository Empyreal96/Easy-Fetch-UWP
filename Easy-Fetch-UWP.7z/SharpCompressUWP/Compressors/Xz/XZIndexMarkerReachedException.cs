﻿using System;

namespace SharpCompress.Compressors.Xz
{
    public class XZIndexMarkerReachedException : Exception
    {
    }
}
