﻿namespace SharpCompress.Compressors.PPMd
{
    public enum PpmdVersion
    {
        H,
        H7Z,
        I1
    }
}