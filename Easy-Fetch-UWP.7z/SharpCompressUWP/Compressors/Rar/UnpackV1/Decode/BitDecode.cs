namespace SharpCompress.Compressors.Rar.UnpackV1.Decode
{
    internal class BitDecode : Decode
    {
        internal BitDecode()
            : base(new int[PackDef.BC])
        {
        }
    }
}