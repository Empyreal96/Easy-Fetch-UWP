﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phone_Helper
{
    class GlobalStrings
    {
        public static string Downloaders_GeneralDownloaderFileName { get; set; }
        public static bool FileNameAccepted { get; set; }
        public static string Logger { get; set; }
    }
}
